RiverCompute Intelligence Knowledge Package

Purpose:
Power Apps/DataShuffle-ready datasets and knowledge base files for a functional AI infrastructure governance app.

Contents:
01_core_assumptions.csv
02_cooling_architecture.csv
03_risk_factors.csv
04_compute_zoning_framework.csv
05_mshdi_score_rules.csv
06_decision_rules.csv
07_knowledge_base_qna.csv
08_product_features.csv
09_generator_function_specs.csv
rivercompute_knowledge_base.json

Use:
Import CSVs as tables/collections. Use stable ID columns as keys. Connect button actions to generator functions listed in 09_generator_function_specs.csv and rivercompute_knowledge_base.json.
